/***************************************************************************
 ** FILE: CandySet.hpp 
 ** AUTHOR: Simba Kutadzaushe
 ** DATE: 02 December 2022
 **   Implementation for Candy class and its methods
 **       --> defines a single node from a binary tree
 ***************************************************************************/

#include "CandySet.hpp"

#include <iostream>

using namespace std;

CandyNode* findHelper(const string &, const CandyNode *);
CandyNode* insertHelper(CandyNode *intoSubTree, const CandyNode *newNode);
void printHelper(const CandyNode *subtree, ostream &os);
void treePrint(const CandyNode *subtree, ostream &os);

CandyNode* 
CandySet::find(const string &findMe) const //Method that returns a non constant pointer
{
	return findHelper(findMe, _root);
}

CandyNode* findHelper(const string &val, const CandyNode *nodePtr)
{
	if (!nodePtr) // No nodes left to search !
		return NULL;
		
	if (nodePtr->value() == val)
		return (CandyNode *) nodePtr;  
		
	if ( val > nodePtr->value()  )
		return findHelper(val, nodePtr->right() );
	else // if val < ...
		return findHelper(val, nodePtr->left() );	
}

void 
CandySet::insert(const std::string &valueToAdd) //Method called insert used to add Candy to the tree
{
	
	if (find( valueToAdd ) /*!= NULL*/ ) 
	{
		return;		
	}		
	
	CandyNode *newTreeNode = new CandyNode(valueToAdd); // New Binary tree to store copy of candy
	_root = insertHelper(_root, newTreeNode);
}

CandyNode* insertHelper(CandyNode *intoSubTree, const CandyNode *newNode) // A method used to insert into the Candy
{

	if (!newNode) //if (newNode == NULL)
	{
		return (TreeNode *) intoSubTree;
	}
	
	if (!intoSubTree)
	{
		return (CandyNode *) newNode;
	}

	if 	( newNode->value() < intoSubTree->value() ) //Condition to copy old tree into a new node
	{
		intoSubTree->left() = insertHelper( intoSubTree -> left() , newNode ); // insert into left subtree and update our left subtree pointer accordingly

		intoSubTree->left()->parent() = intoSubTree; 	// Update left subtree's "parent" pointer
	}
	else //  so must need to insert into right side
	{
		intoSubTree->right() = insertHelper( intoSubTree -> right() , newNode ); 	// insert into right subtree, and update our right subtree pointer accordingly
				
		intoSubTree->right()->parent() = intoSubTree; // update right subtree's "parent" pointer
	}
	
	return intoSubTree;
}

void 
CandySet::remove(const std::string &valueToDelete)
{
	CandyNode *toDel = find(valueToDelete);

	if (!toDel)
		return;	
	
	// test for which case we are in ....
	
	if (toDel->isLeaf())
	{
		// think about this ... there is only one node in tree!
		if (toDel == _root)
		{
			_root = NULL;
			return;
		}
		
		CandyNode *parent = toDel->parent();
		if (parent->left() == toDel)
			parent->left() = NULL;
		else // must be right child
			parent->right() = NULL;
			
		//toDel->parent() = toDel->left() = toDel->right() = NULL;
	}
	// check for one child case
	else if ( (toDel->left() && !toDel->right() ) // have left but no right child
							||
				 (!toDel->left() && toDel->right() ) // have no left but yes on right child
			  )
	{
		if (toDel == _root)
		{
			if (toDel->left()) // is the only child on the left?
				_root = toDel->left();
			else // the only child is on the right
				_root = toDel->right();
				
			_root->parent() = NULL;
			return;
		}
		
		CandyNode *subtreeToMove;
		if (toDel->left()) // left subtree is the 1 child
			subtreeToMove = toDel->left();
		else // right subtree is the 1 child 	
			subtreeToMove = toDel->right();
		
	 CandyNode *parent = toDel -> parent();
		if (parent->left() == toDel)	
			parent->left() = subtreeToMove;
		else
			parent->right() = subtreeToMove;	

		subtreeToMove->parent() = parent;
	}
	else // 
	{
		CandyNode *largestInLeft;
		largestInLeft = toDel->left();
		while(largestInLeft->right() != NULL)
		{
			largestInLeft = largestInLeft->right();
		}		
		
		string dataToKeep = largestInLeft -> value();
		
		remove (dataToKeep);
		toDel->value() = dataToKeep;		
		
		
	}
	
}

ostream& operator<<(ostream &stream, const BinaryTree &bt)
{
	//printHelper( bt._root , stream );
	treePrint( bt._root , stream );
	return stream;
}

void printHelper(const CandyNode *subtree, ostream &os)
{
	if (!subtree)
		return;
	
	printHelper(subtree->left(), os);
	os << subtree->value() << endl;	
	printHelper(subtree->right(), os);	
}

void CandyPrint(const TreeNode *subtree, ostream &os)
{
	if (!subtree)
		return;
	
	treePrint(subtree->right(), os);
	for(unsigned int ntabs =0; ntabs < subtree->depth() ; ntabs++)
		os << "         "; 
	os << subtree->value() << endl;	
	treePrint(subtree->left(), os);	
}

