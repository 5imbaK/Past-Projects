/***************************************************************************
 ** FILE: CandyNode.cpp 
 ** AUTHOR: Simba Kutadzaushe 
 ** DATE: 02 December 2022
 **   Implementtation for CandyNode class and its methods for 
 **     project #4 in Fall 2022
 **       --> defines a single node from a binary tree
 ***************************************************************************/


#include "CandyNode.hpp"	
	
bool 
CandyNode::isLeaf() const
{
	return !_right && !_left;
	/
	if (!_right && !_left)
		return true;
	else
		return false;
	
}


unsigned int 
CandyNode::depth() const
{
	unsigned int ancestorCount=0;
	
	CandyNode *curr = (CandyNode *) this; 	
	while(curr->_parent!=NULL)
	{
		ancestorCount++;
		curr = curr->_parent;
	}		
	
	return ancestorCount;
}
