/***************************************************************************
 ** FILE: CandyNode.hpp 
 ** AUTHOR: Simba Kutadzaushe 
 ** DATE: 02 December 2022
 **   Implementation for CandyNode class and its methods for CSC24400 project #4 
 **       --> defines a single node from a binary tree
 ***************************************************************************/

#ifndef _CANDY_NODE_HPP_
#define _CANDY_NODE_HPP_

#include <iostream>
#include <string>

class CandyNode
{
private:
	std::string _element;
	CandyNode *_left;
	CandyNode *_right;
	CandyNode *_parent;		
public:	
	CandyNode(const std::string &data):
		_element(data), _left(NULL), _right(NULL), _parent(NULL) {}
	
	// accessors 
	const std::string& value() const {return _element;}
   const CandyNode* left() const {return _left;}
   const CandyNode* right() const {return _right;}
   const CandyNode* parent() const {return _parent;}

	// modifiers
	std::string& value() {return _element;}
   CandyNode* & left() {return _left;}
   CandyNode* & right() {return _right;}
   CandyNode* & parent() {return _parent;}
	
	bool isLeaf() const;
	unsigned int depth() const;
};

#endif