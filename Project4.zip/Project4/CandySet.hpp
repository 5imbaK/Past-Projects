/***************************************************************************
 ** FILE: CandySet.hpp 
 ** AUTHOR: Simba Kutadzaushe
 ** DATE: 02 December 2022
 **   Implementation for Candy class and its methods for CSC24400 project #2 
 **       --> defines a single node from a binary tree
 ***************************************************************************/

#include "CandyNode.hpp"	
	
bool 
CandyNode::isLeaf() const
{
	return !_right && !_left;
	
	if (!_right && !_left)
		return true;
	else
		return false;
	
}


unsigned int 
CandyNode::depth() const
{
	unsigned int ancestorCount=0;
	
	CandyNode *curr = (CandyNode *) this; 	
	while(curr->_parent!=NULL)
	{
		ancestorCount++;
		curr = curr->_parent;
	}		
	
	return ancestorCount;
}
