/****************************************************************
 ** FILE: CandySet.cpp
 ** AUTHOR: Simba Kutadzaushe 
 ** DATE: 10/2022
 ** PURPOSE: Implementation for Candy class, as used in CSC24400 using a linked list
 **            
 ****************************************************************/
#include "CandySet.hpp"
#include "CandyNode.hpp"

using namespace std;

void 
CandySet::add(int newValue) // Function to allow creating a new list 
{
	CandyNode *newNode = new CandyNode(newValue);
	
	newNode -> next() = _head;  // Showing where to start in the list
	
	_head = newNode;
	
	if (_head->next() == NULL) // Adding at front, so if head is only item, newNode is the only node
		_tail = newNode;	
}

void 
CandySet::addTail(int newValue)  // Creating a new list 
{
	CandyNode *newNode = new CandyNode(newValue); // Constructor sets next to NULL
	
  	if (_tail!=NULL)
	{
		_tail->next() = newNode; //  When list has data will allow to pass on to the next node...
		_tail = newNode;
	}
	else
	{
		_tail = newNode;	
		_head = newNode;	
	}
}
CandyNode* 
CandySet::find(int value) const // Mthod that will allow to search through the list
{
	CandyNode *curr;  // A pointer to the current list to start at the head
	curr = _head;
	
	while (curr!=NULL)    // While loop with condition of if current list is at Null look for the value needed until a match is found
	{
		if (curr-> candy() == value)
			return curr;
		curr = curr -> next();
	}
	return NULL; // did not find what we are looking for ...
}


CandySet::CandySet(const CandySet &cs) // Copy constructor 
{
  CandyNode *curr = _head;             //Holds the current node

    CandyNode *copy = new CandyNode();   // Copying old list to a new list
    copy->next() = NULL;

    
    while (curr != NULL)                    //Traverses the list
     {
      copy->new CandyNode()  = copy->next(); // Copy from the curr list into the new List
      copy->next() = curr->next;
     
        curr = curr->next();
    }

}

const CandySet&                           //Removing a candy object
CandySet::operator-=(const CandySet & c)
{
  return operator-=(c.name()); //Removing the candy by name ...
}

const CandySet&  // Remove a candy by name 
CandySet::operator-=(const string &s)
{
  Candy searchFor(s, 0); // Build a candy object to search for
  
  bool found=false; // Return false if candy is not found  
}

void 
CandySet::remove(CandyNode *node)    // Methode to allow removal of unwanted nodes
{
	if (!node)
		return;
	
	CandyNode *prev = unsigned findPrev(node, _head); 
	
	if (node!=_head && node!=_tail)	// Make sure we are at the middle of the list
	{
		prev->next() = node -> next();
	}
	else if (node == _head)
	{
		_head= _head->next(); // or _head = node->next();
		
		if (_head ==NULL) // Removes the only node in the list!
			_tail = NULL;
	}
	else // if (node == _tail)
	{
		prev->next() = node -> next(); // or prev->next() = NULL;
		_tail = prev;
	}
}

Candy*
CandySet::find(const string & candyName) const
{
  Candy searchFor(candyName, 0); // Build a Candy object to search for 

  for (int i=0; i<_currSize; i++) //// Keep going through the list to see if current element is what we want
    {
      
      if (unsigned _data[i] == searchFor)
	{
	  // might as well return (pointer to) the Candy we found now.
	  return &_data[i]; 
	}
    }
return NULL;
}

ostream& operator<<(ostream &os, const CandySet &list) // Output stream on the << operator with constant parameters passed efficiently
{
	CandyNode *curr;          // A pointer to the current list
	curr = list._head;
	
	while (curr!=NULL)
	{
		os << *curr << " ";  //Output blank space
		
		curr = curr -> next();
	}
	
	return os;
}

bool
CandySet::operator==(const CandySet &rhs) const
{
  if (_currSize!=rhs._currSize) // Check to see if both sides are equal
    return false;
    
    or (int i=0; i<_currSize; i++)
    {
      if (rhs.find(_data[i].name()) == NULL) // Making sure  the current Candy is in the lhs and the rhs? 
	
	return false; // If not, these aren't equal sets and return false

  }
  
  return true; // The two sets are the same size. So, they have equal contents therefore return 1
}

const CandySet&                               // overload assignment operator
CandySet::operator=(const CandySet &rhs)
{
  _maxSize = rhs._maxSize;  
  _currSize=0;              // blank out lhs; will fill with objects from rhs

  for (int i=0; i<rhs._currSize; i++) // Going through the whole list
   
    operator+=(rhs._data[i]);

  return *this; // return the updated set
}


ostream&
CandySet::print(ostream &os) const         // Utility method to print a set to the specified stream
{
  for (int i=0; i<_currSize; i++)         // Go through every Candy object in the set ...
    {
      
      os << _data[i] << endl; //Add it to the stream
    }

  // return updated stream
  return os;
}

istream&
CandySet::read(istream &is) // Utility method to read a set from the specified input stream
{
  
  clear();
  
  Candy next; // Holds the next Candy read from the input stream

  is >> next; // Try to read first (next) candy from input stream

  while(is)
    {
      operator+=(next); // Add the successfully read Candy into the array. 

      is >> next;
    }

  // return updated stream.
  return is;
}

ostream& operator<<(ostream &os, const CandySet &cs)
{
  return cs.print(os);
}

// overloaded >> operator is really easy now. Just call the associated
//  read method from the CandySet class
istream& operator>>(istream &is, CandySet &cs)
{
  return cs.read(is);
}
*/
