/*************************************************************
 ** FILE: CandySet.hpp
 ** AUTHOR: Simba Kutadzaushe
 ** DATE: 21 November 2022
 ** PURPOSE: Header file for Candy class, as used in CSC24400 using a linked lists
 *************************************************************/
#ifndef _CANDY_SET_HPP_
#define _CANDY_SET_HPP_

#include <iostream>
#include <string>

#include "Candy.hpp"
#include "CandyNode.hpp"

class CandySet
{
	
private:
 
 CandyNode *_head;   // Pointer to underlying list
 CandyNode *_tail;
 int _currSize;     // How many elements are in the set right now
 int _maxSize;      // Maximum number of elements set could hold right now
  
public:

  CandySet(std::istream &is);         // Fill set from given input stream
  CandySet(int maxSize);          // Build set with specified maximum elements
  CandySet(const CandySet &cs); 
  
  CandySet() : _head(NULL), _tail(NULL) {}  // Default constructor
	
	void add(int newValue);	           // Methods with no return value which manipulate the list
	void addTail(int newValue);	

	CandyNode* find(int value) const;
	void remove(CandyNode *node);
	void remove(int value);	
	
	friend std::ostream& operator<<(std::ostream &os, const CandySet &list);	

 // operator overloads
  const CandySet& operator+=(const CandySet & c); // Add a Candy to set
  const CandySet& operator-=(const CandySet & c); // Remove a candy from set
  const CandySet& operator-=(const std::string &candyName); //Remove by name

  Candy* find(const std::string &candyName) const; // Return a pointer to requested candy name (if found)

  
  bool operator==(const CandySet &other) const;       // Equality comparators
  bool operator!=(const CandySet &other) const {return !(*this==other);}

  int size() const {return _currSize;} // How many Candy objects are in set?
  
  int spaceLeft() const {return _maxSize-_currSize;} // How much room is left?

  void clear() {_currSize=0;} // Empty out set there are now 0 Candy objects to look at!
  
  const CandySet& operator=(const CandySet &rhs);

  std::ostream& print(std::ostream &os) const; // Print CandySet to stream
  std::istream& read(std::istream &is);        // Read CandySet from stream
  
};

std::ostream& operator<<(std::ostream &os, const CandySet &cs); // Using above public methods, do not need to make these two functions friends. 
std::istream& operator>>(std::istream &is, CandySet &cs);


#endif





