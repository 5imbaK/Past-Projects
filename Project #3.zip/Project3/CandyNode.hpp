#ifndef _CANDY_NODE_HPP_
#define _CANDY_NODE_HPP_

#include <iostream>

class CandyNode 
{
private:
	unsigned _element;
	CandyNode *_next;
public:
	CandyNode : _element,  _next {}
	
	unsigned candy() const {return _element;} // accessor
	unsigned & candy() {return _element;}      // modifier
	
	CandyNode* next() const {return _next;}    // accessor
	CandyNode* & next() {return _next;}
	CandyNode *copy () {}
	CandyNode *newNode () {}
	
	friend std::ostream& operator << (std::ostream &os, const CandyNode &ln); 
};

#endif

