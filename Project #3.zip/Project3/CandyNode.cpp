#include "CandyNode.hpp"

using namespace std;
ostream& operator << (ostream &os, const CandyNode &ln)
{
	os << ln.element();
	return os;
}