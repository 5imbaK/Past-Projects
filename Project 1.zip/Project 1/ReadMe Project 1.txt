Simbarashe Kutadzaushe

10/04/2022

Linux & Windows(Visual Studio)


-Code does not compile
-My function to print out the board did not come out very well
-Was using the NQueens solution as my reference
-Created separate functions for my knighttour and to find the knight tour
-Due to failing to compile code could not check if functions work
-Started my code in linux and then went to visual studios because was failing to compile code in linux
-Code does look complete, l am satisfied with it