//File: Prog Proj 1
//Author : Simbarashe Kutadzaushe
//Date : October 4 2022
//Purpose : Solve Programming Project #1. Prompt the user to input the board size and enter a position for the knightand prints out move made
//and if move is possible

#include <cmath>
#include <fstream>
#include <iostream>
#include <string>

#define BOARD_SIZE 100

using namespace std;


char board[BOARD_SIZE][BOARD_SIZE];

void intitBoard(int numRows, int numCols)

{
	for (int row = 0; row <  numRows; row++)
	{
		for (int col = 0; col < numCols; col++)
		{
			board[row][col] = ' ';
		}
	}
}

void printRowBorder(int numRows, int numCols)// Function to 
{
	cout << "+";

	for (int numCells = 0; numCells < numCols; numCells++)
		cout << "+";
	{
		for ( int numCells = 0; numCells < numRows; numCells++)

		cout << "-+";

	cout << endl;

}

void printBoard(int numRows, int numCols) //Function to printout the rows of the board
	{
		printRowBorder(numCols);
			for (int row = (numCols)-1; row >= 0; row--)
			{
			cout << "|";
			for (int col = 0; col < numCols; col++)
			{
				cout << board[row][col] << "|";
			}
			cout << endl;
			printRowBorder(numCols);

		}
	}


bool canPlace(int row, int col, int n)
{
	if (row < 0 || col < 0 || row >= n || col >= n || board[row][col] != 0) return false;// a check to see if knight can be placed on board
		return true;

	}
bool findKnightTourSol()
 {
	for (int x = 0; x < N; x++)     //initially set all values to -1 of solution matrix
		for (int y = 0; y < N; y++)
			sol[x][y] = -1;
	//all possible moves for knight
	int xMove[8] = { 2, 1, -1, -2, -2, -1,  1,  2 };
	int yMove[8] = { 1, 2,  2,  1, -1, -2, -2, -1 };
	sol[0][0] = 0;     //starting from room (0, 0)

	if (knightTour(0, 0, 1, sol, xMove, yMove) == false) {
		cout << "Solution does not exist";
		return false;
	}
	else
		displaySolution();
	return true;
}

void solve(int numRows, int numCols,int n, int count)
{
	if (count == n * n)// if function with condition 
	{
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
			{
				cout << board[i][j] << " ";//output on board leaving a space
			}
			cout << endl;
		}
		cout << endl;
		return;
	}

}

int knightTour(int x, int y, int move, int sol[N][N], int xMove[N], int yMove[N]) {
	int xNext, yNext, isValid;
	if (move == N * N)     //when the total board is covered
		return true;

	for (int k = 0; k < 8; k++) {
		xNext = x + xMove[k];
		yNext = y + yMove[k];
		if (isValid(xNext, yNext, sol)) {     //check room is preoccupied or not
			sol[xNext][yNext] = move;
			if (knightTour(xNext, yNext, move + 1, sol, xMove, yMove) == true)
				return true;
			else
				sol[xNext][yNext] = -1;// backtracking
		}
	}
	return false;
}


int main(int argc, char* argv[])

 {
	cout << "Enter the size of the board";
	int numRows, numCols;
	cin >> numRows;
	cin >> numCols;
	

	intitBoard(numRows,numCols);//calling function intitBoard
	printBoard(numRows,numCols); //Calling function printboard
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	solve(numRow, numCol, n,count);
	//printBoard(bSize);

	cout << "Enter the initial knight location"; //Prompt the user to input knights location
	int intRows, intCols;
	cin >> intRows;
	cin >> intCols;

	findKnightTourSol();// calling function 
	knightTour(x, y, move, sol[N][N], xMove[N], yMove[N])
	
		return 0;

 }