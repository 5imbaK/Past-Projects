/*************************************************************
 ** FILE: CandySet.hpp
 ** AUTHOR: Simba Kutadzaushe 
 ** DATE: 11/09/20222
 ** PURPOSE: Header file for CandySet class
 *************************************************************/
#ifndef _CANDYSET_HPP_
#define _CANDYSET_HPP_

#include <iostream>
#include <string>
#include "CandySet.hpp"

using namespace std;

class CandySet
{
private:                     // Constructor that initializes array and size 
    CandySet *_arr;  
            
    unsigned int _size;   
    unsigned int _filled; 
public:
    
    CandySet(); // default constructors

    CandySet(int numOfCandyObjects); // Non-default constructor that takes in a size of the candy set array

    CandySet(istream &candyData); // Non-default constructor that takes in a stream of Candy objects

    CandySet(const CandySet &other); // Create a copy constructor with parameter not to be changed 

    CandySet *find(const string stringParam);

    int size();         // Initialize methods with appropriate types
    int spaceLeft();
    void clear();       // Construction of a method with name Clear

    const CandySet &operator+=(const CandySet candy);// overload methods for adding and removing Candy objects to the CandySet
    const CandySet &operator-=(const CandySet candy);
    const CandySet &operator-=(const string stringParam);

    bool operator==(const CandySet &incommingCandySet) const; // overload some comaprison operators between CandySet objects
    bool operator!=(const CandySet &incommingCandySet) const;

    const CandySet &operator=(const CandySet incommingCandySet);  // assignment operator overload for CandySet

    friend ostream &operator<<(ostream &out, const CandySet &candySet); // Overloading the << output and >> input operators
    friend istream &operator>>(istream &in, CandySet &candySet);  // use friend functions to access private members of CandySet 
};
#endif