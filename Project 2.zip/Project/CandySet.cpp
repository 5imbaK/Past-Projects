/****************************************************************
** FILE: CandySet.cpp
** AUTHOR: Simba Kutadzaushe 
** DATE: 11/09/2022
** PURPOSE: Implementation for CandySet class
****************************************************************/
#include <iostream>
#include <string>
#include "Candyset.hpp"

using namespace std;

#define MAX_SIZE 5          // Instruct constructor to be capable of holding 5 objects

CandySet::CandySet()        //Default constructor that takes no arguments.
{
    _size = MAX_SIZE;       
    _filled = 0;            //Initializing constructor to hold zero objects
    _arr = new Candy[_size];
}

CandySet::CandySet(istream &is)     // Create a constructor that takes a single argument of type istream adding as many Candy objects as there are in the input stream to the collection
{
    _size = MAX_SIZE;
    _filled = 0;
    _arr = new Candy[_size];
    while (!is.eof())
    {
        Candy candy;
        is >> candy;
        *this += candy;
    }
}

CandySet::CandySet(int numOfCandyObjects)  //a constructor that takes one integer argument. 
{
    _size = numOfCandyObjects;             //Make the collection be capable of holding up to that integer number of Candy objects
    _filled = 0;                           //initializing constructor to holds zero objects.
    _arr = new Candy[_size];
}

CandySet::CandySet(const CandySet &candySet)  //Copy constructor that takes in as its only parameter an existing CandySet and duplicates the existing CandySet.
{
    _size = candySet._size;
    _filled = candySet._filled;
    _arr = new Candy[_size];                //brand new set that contains the same Candy as the set being copied with no reference to original array
    for (int i = 0; i < _filled; i++)
    {
        _arr[i] = candySet._arr[i];
    }
}


const CandySet &
CandySet::operator+=(const Candy candy)// Overloading the += operator so that RHS is an object not to be modified and passed efficiently
{
    for (int i = 0; i < _filled; i++)  //Use the for loop to go through the whole array
    {
        if (_arr[i].name() == candy.name())
        {
            return *this;              // Return this when condition is met
        }
    }
    if (this->spaceLeft() == 0)
    {
        
        _size *= 2;                         // Allocate a new array of twice the maximum size of the current one
        Candy *newArr = new Candy[_size];
        
        for (int i = 0; i < _size; i++)
        {
            newArr[i] = _arr[i]; // copy the contents of the old array into the new array
        }
        
        delete[] _arr;// Delete the old array
        
        _arr = newArr; // Set the old array pointer to the new array
    }
    _arr[_filled] = candy;
    _filled++;
    return *this;
}



const CandySet &
CandySet::operator-=(const string stringParam) // Overloading the -= so that the RHS would be a string
{
    for (int i = 0; i < _filled; i++)
    {
        if (_arr[i].name() == stringParam)
        {
            for (int j = i; j < _filled; j++)
            {
                _arr[j] = _arr[j + 1];
            }
            _filled--;
        }
    }
    return *this;
}

const CandySet &
CandySet::operator-=(const Candy candy) // Overloading the -= operator so that RHS will be a Candy Object passed efficiently and not to be changed
{
    for (int i = 0; i < _filled; i++)
    {
        if (_arr[i].name() == candy.name())
        {
            for (int j = i; j < _filled; j++)
            {
                _arr[j] = _arr[j + 1];
            }
            _filled--;
        }
    }
    return *this;
}

Candy *
CandySet::find(const string stringParam) // Creating a method called find that takes a single constant parameter passed efficiently
{
    for (int i = 0; i < _filled; i++)         //if the Candy named by the parameter is found in this CandySet, 
    {                                         //then a pointer to that Candy object should be returned;
        if (_arr[i].name() == stringParam)    //
        {
            return &_arr[i];
        }
    }
    return NULL;
}

int CandySet::size() //Method called size that takes no parameters and returns an integer.
{
    return _filled; //Simply return the actual number of different Candy objects in this CandySet.
}


int CandySet::spaceLeft()  //Method called spaceLeft that takes no parameters and returns an integer. .
{                          //This method should simply return the number of additional Candy objects that can be added to this CandySet before it is full
    return _size - _filled;
}

bool CandySet::operator==(const CandySet &incommingCandySet) const//The == operator should be overloaded so that the right hand side is another CandySet object (passed efficiently as a constant, returning bool
{
    if (_filled != incommingCandySet._filled)
    {
        return false;
    }
    for (int i = 0; i < _filled; i++)
    {
        if (_arr[i] != incommingCandySet._arr[i])
        {
            return false;
        }
    }
    return true;
}


bool CandySet::operator!=(const CandySet &incommingCandySet) const//Overload the != so that the RHS is a CandySet returning bool
{
    return !(*this == incommingCandySet);
}



//
void CandySet::clear() // Create a  method called clear that simply empties out the set. 
{
    _filled = 0;       // Intilize method to null and return nothing
}

const CandySet &
CandySet::operator=(const CandySet incommingCandySet)  // Overload the = operator
{
    if (this != &incommingCandySet)
    {
        _size = incommingCandySet._size;
        _filled = incommingCandySet._filled;
        delete[] _arr;
        _arr = new Candy[_size];
        for (int i = 0; i < _filled; i++)
        {
            _arr[i] = incommingCandySet._arr[i];
        }
    }
    return *this;                                  // Method should return a copied Candyset efficiently and not to be modified
}


ostream &
operator<<(ostream &out, const CandySet &candySet) //Overloading the << operator

{
    for (int i = 0; i < candySet._filled; i++)
    {
        out << candySet._arr[i] << endl;
    }
    return out; // Return reference to on object of type stream
}

istream &
operator>>(istream &in, CandySet &candySet) // the >> operator should be overloaded for a CandySet object. This method should return a reference to an object of type istream.
{
    Candy candy;
    while (in >> candy)
    {
        candySet += candy;
    }
    return in;
}

 
Candy *
CandySet::find(const string stringParam) // a method called find that takes a single parameter of type string (as a constant passed efficiently.) This method should return a (non-constant) pointer to a Candy object.
{
    for (int i = 0; i < _filled; i++)
    {
        if (_arr[i].name() == stringParam)
        {
            return &_arr[i];
        }
    }
    return NULL;
}

int CandySet::size()   // Create method called size that takes no parameters and  return the actual number of different candy objects
{
    return _filled;
}

int CandySet::spaceLeft() // Creating a method with the name spaceleft that returns the number of additional of candy objects
{
    return _size - _filled;
}

bool CandySet::operator==(const CandySet &incommingCandySet) const // Overload the == operator so that RHS is a another CandySet object and return a bool  
{
    if (_filled != incommingCandySet._filled)
    {
        return false;
    }
    for (int i = 0; i < _filled; i++)
    {
        if (_arr[i] != incommingCandySet._arr[i])
        {
            return false;
        }
    }
    return true;
}


bool CandySet::operator!=(const CandySet &incommingCandySet) const // Overloading the != operator 
{
    return !(*this == incommingCandySet); //return the opposite value from what the corresponding overloaded == operator above
}

void CandySet::clear() // Adding a method that clears out the set and assign it to null
{
    _filled = 0;
}

const CandySet &                                     // Overload the = operator with same conditions as operator before
CandySet::operator=(const CandySet incommingCandySet)
{
    if (this != &incommingCandySet)
    {
        _size = incommingCandySet._size;
        _filled = incommingCandySet._filled;
        delete[] _arr;
        _arr = new Candy[_size];
        for (int i = 0; i < _filled; i++)
        {
            _arr[i] = incommingCandySet._arr[i];
        }
    }
    return *this;
}


ostream &
operator<<(ostream &out, const CandySet &candySet)// the << operator should be overloaded for a CandySet object. 
{
    for (int i = 0; i < candySet._filled; i++)
    {
        out << candySet._arr[i] << endl;
    }
    return out;
}


istream &
operator>>(istream &in, CandySet &candySet)// The >> operator should be overloaded for a CandySet object. This method should return a reference to an object of type istream.
{
    Candy candy;
    while (in >> candy)
    {
        candySet += candy;
    }
    return in;
}